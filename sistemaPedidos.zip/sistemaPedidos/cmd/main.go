package main

import (
	"pedidos/internal/data"
)

func main() {
	data.LoadPedidos()
	

}

//go init Loja
