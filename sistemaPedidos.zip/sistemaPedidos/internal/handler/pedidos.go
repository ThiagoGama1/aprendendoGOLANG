package handler

import (
	"net/http"
	"pedidos/internal/data"
	"pedidos/internal/models"
	"pedidos/internal/service"

	"github.com/gin-gonic/gin"
)

func CreatePedido(c *gin.Context) {
	var NovoPedido models.Pedido
	var validandoPreco = service.ValidaPrecoPedido(&NovoPedido)
	var validandoQuantidade = service.ValidaQuantidade(&NovoPedido)
	if err := c.ShouldBindJSON(&NovoPedido); err != nil{
		c.JSON(http.StatusBadRequest, gin.H{"erro": err.Error()})
		return
	}
	if validandoQuantidade != nil{
		c.JSON(http.StatusBadRequest, gin.H{"erro": validandoQuantidade.Error()})
		return
	}
	
	if validandoPreco != nil{
		c.JSON(http.StatusBadRequest, gin.H{"erro": validandoPreco.Error()})
		return
	}
	NovoPedido.ID = len(data.Pedidos) + 1
	data.Pedidos = append(data.Pedidos, NovoPedido)
	data.SavePedido()
	c.JSON(http.StatusCreated, NovoPedido)
}