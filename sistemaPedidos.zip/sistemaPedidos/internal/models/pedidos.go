package models

type Pedido struct {
	ID         int     `json:"id"`
	Cliente    string  `json:"cliente"`
	PizzaID    int     `json:"pizza_id"`
	Quantidade int     `json:"quantidade"`
	ValorTotal float64 `json:"valor_total"`
}