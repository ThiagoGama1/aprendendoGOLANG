package service

import (
	"errors"
	"pedidos/internal/models"
)

func ValidaPrecoPedido(Pedido *models.Pedido) error{
	if Pedido.ValorTotal < 0{
		return errors.New("O valor deve ser maior ou igual a zero!")
	}
	return nil
}

func ValidaQuantidade(Pedido *models.Pedido) error{
	if Pedido.Quantidade <= 0{
		return errors.New("Quantidade inválida!")
	}
	return nil
}