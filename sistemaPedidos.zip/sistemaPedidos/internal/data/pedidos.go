package data

import (
	"encoding/json"
	"fmt"
	"os"
	"pedidos/internal/models"
)

var Pedidos []models.Pedido

func LoadPedidos(){
	file, err := os.Open("dados/pedidos.json")
	if err != nil{
		return
	}
	defer file.Close()
	json.NewDecoder(file).Decode(&Pedidos)
	
}
func SavePedido(){
	file, err := os.Create("dados/pedidos.json") // como eu usei o :=, eu ja criei um file com o tipo igual ao retorno da funcao create (ponteiro pro file)

	if err != nil {
		fmt.Println("Error file:", err)
		return
	}
	defer file.Close()

	encoder := json.NewEncoder(file) // envia de dentro pra fora
	if err := encoder.Encode(&Pedidos); err != nil {
		fmt.Println("Error encoding JSON: ", err)
	}
}