package handler

import (
	"manual/internal/data"
	"manual/internal/models"
	"net/http"
	"strconv"

	"github.com/gin-gonic/gin"
)

func ListarManuais(c *gin.Context){
	c.HTML(http.StatusOK, "index.html", gin.H{"Manuais": data.Manuais})
}

func ExibirManualPorId(c *gin.Context){
	idManual := c.Param("id")
	id, err := strconv.Atoi(idManual)

	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"erro": err.Error()})
		return
	}
	for _, m := range data.Manuais {
		if m.ID == id{
			c.HTML(http.StatusOK, "visualizar.html", m)
			return
		}
	}
	c.JSON(http.StatusNotFound, gin.H{"message": "Manual não existente"})
}

func CriarManual(c *gin.Context){
	novoId := len(data.Manuais) + 1
	inputTitulo := c.PostForm("titulo")
	inputConteudo := c.PostForm("conteudo")

	novoManual := models.Manual{ID: novoId, Titulo: inputTitulo, Conteudo: inputConteudo}
	data.Manuais = append(data.Manuais, novoManual)
	data.SaveManuais()
	c.Redirect(http.StatusSeeOther, "/")
}

func DeleteManualById(c *gin.Context){
	idParam := c.Param("id")
	id, err := strconv.Atoi(idParam)

	if err != nil {
		c.JSON(http.StatusNotFound, gin.H{"erro": err.Error()})
		return
	}

	for i, m := range data.Manuais{
		if m.ID == id{
			data.Manuais = append(data.Manuais[:i], data.Manuais[i+1:]...)
			data.SaveManuais()
			c.Redirect(http.StatusFound, "/")
			return
		}
	}
	c.Redirect(http.StatusNotFound, "/")
}

func UpdateManualById(c *gin.Context){
	idParam := c.Param("id")
	id, err := strconv.Atoi(idParam)
	if err != nil{
		c.Redirect(http.StatusNotFound, "/")
		return
	}

	for _, m := range data.Manuais{
		if m.ID == id{
			c.HTML(http.StatusOK, "editar.html", m)
			return
		}
	}
}
func RecebeUpdateById(c * gin.Context){
	idParam := c.Param("id")
	id, err := strconv.Atoi(idParam)

	if err != nil{
		c.Redirect(http.StatusNotFound, "/")
		return
	}
	inputTitulo := c.PostForm("titulo")
	inputConteudo := c.PostForm("conteudo")
	for i, m := range data.Manuais{
		if m.ID == id{
			data.Manuais[i].Titulo = inputTitulo
			data.Manuais[i].Conteudo = inputConteudo

			data.SaveManuais()
			
			c.Redirect(http.StatusFound, "/")
			return
		}
	}
	c.Redirect(http.StatusSeeOther, "/")
}