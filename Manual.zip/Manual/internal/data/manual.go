package data

import (
	"encoding/json"
	"fmt"
	"manual/internal/models"
	"os"
)

var Manuais	[]models.Manual

func LoadManuais() {
	file, err := os.Open("dados/manual.json")

	if err != nil{
		fmt.Println("Falha ao carregar os manuais!")
		return
	}
	defer file.Close()

	decoder := json.NewDecoder(file) // traz de fora pra dentro

	if err := decoder.Decode(&Manuais); err != nil {
		fmt.Println("Error decoding JSON: ", err)
	}

}

func SaveManuais() {
	file, err := os.Create("dados/manual.json")

	if err != nil{
		fmt.Println("Erro ao salvar.", err)
		return
	}
	defer file.Close()

	encoder := json.NewEncoder(file)

	if err := encoder.Encode(&Manuais); err != nil{
		fmt.Println("Error encoding JSON: ", err)
	}
}