package main

import (
	"manual/internal/data"
	"manual/internal/handler"

	"github.com/gin-gonic/gin"
)

//go mod init manual
func main(){
	data.LoadManuais()
	router := gin.Default()
	router.LoadHTMLGlob("templates/*")
	router.GET("/", handler.ListarManuais)
	router.GET("/manual/:id", handler.ExibirManualPorId)
	router.GET("/novo", func(c *gin.Context) {
    	c.HTML(200, "form.html", nil)
	})
	router.POST("/criar", handler.CriarManual)
	router.POST("/deletar/:id", handler.DeleteManualById)
	router.GET("/editar/:id", handler.UpdateManualById)
	router.POST("/atualizar/:id", handler.RecebeUpdateById)

	router.Run()
}