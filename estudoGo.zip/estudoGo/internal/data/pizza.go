package data

import (
	"encoding/json"
	"fmt"
	"os"
	"pizzaria/internal/models"
)
var Pizzas []models.Pizza

func LoadPizzas() {
	file, err := os.Open("dados/pizza.json")

	if err != nil {
		fmt.Println("Error file:", err)
		return
	}
	defer file.Close()
	decoder := json.NewDecoder(file) // traz de fora pra dentro

	if err := decoder.Decode(&Pizzas); err != nil {
		fmt.Println("Error decoding JSON: ", err)
	}
}

func SavePizza() {
	file, err := os.Create("dados/pizza.json") // como eu usei o :=, eu ja criei um file com o tipo igual ao retorno da funcao create (ponteiro pro file)

	if err != nil {
		fmt.Println("Error file:", err)
		return
	}
	defer file.Close()

	encoder := json.NewEncoder(file) // envia de dentro pra fora
	if err := encoder.Encode(Pizzas); err != nil {
		fmt.Println("Error encoding JSON: ", err)
	}
}