package main

import (
	"pizzaria/internal/data"
	"pizzaria/internal/handler"

	"github.com/gin-gonic/gin"
)

// tudo que voce criar/chamar voce tem que usar
func main(){
	data.LoadPizzas()
	router := gin.Default()

	router.GET("/pizzas", handler.GetPizzas)
	router.POST("/pizzas", handler.PostPizzas)
	router.GET("/pizzas/:id",handler.GetPizzasByID)
	router.DELETE("/pizzas/:id", handler.DeletePizzaById)
	router.PUT("/pizzas/:id", handler.UpdatePizzaById)
	//var nomePizzaria string = "Pizzaria Go" //(eu decido o tipo de variavel), recomendado para quando 
	// voce quer deixar claro o tipo, para ter mais controle
	
	//fmt.Println(pizzas)
	//nomePizzaria := "Pizzaria Go" // o go decide o tipo da variável
	//instagram, telefone := "pizzaria_go", "1234-5678" // múltiplas variáveis (short assignment)
	//fmt.Printf("Nome da Pizzaria: %s\nInstagram: %s\nTelefone: %s\n", nomePizzaria, instagram, telefone)

	router.Run() // padrão :8080
}



