package main

import (
	"encoding/json"
	"fmt"
	"os"
	"pizzaria/models"
	"strconv"

	"github.com/gin-gonic/gin"
)
var pizzas []models.Pizza

// tudo que voce criar/chamar voce tem que usar
func main(){
	loadPizzas()
	router := gin.Default()

	router.GET("/pizzas", getPizzas)
	router.POST("/pizzas", postPizzas)
	router.GET("/pizzas/:id",getPizzasByID)
	//var nomePizzaria string = "Pizzaria Go" //(eu decido o tipo de variavel), recomendado para quando 
	// voce quer deixar claro o tipo, para ter mais controle
	
	//fmt.Println(pizzas)
	//nomePizzaria := "Pizzaria Go" // o go decide o tipo da variável
	//instagram, telefone := "pizzaria_go", "1234-5678" // múltiplas variáveis (short assignment)
	//fmt.Printf("Nome da Pizzaria: %s\nInstagram: %s\nTelefone: %s\n", nomePizzaria, instagram, telefone)

	router.Run() // padrão :8080
}

func getPizzasByID(c *gin.Context){
	idParam := c.Param("id")
	id, err := strconv.Atoi(idParam)

	if err != nil {
		c.JSON(400, gin.H{
			"erro": err.Error()})
		return
	}
	for _, p := range pizzas{
		if p.ID == id{
			c.JSON(200, p)
			return
		}
	}
	c.JSON(404, gin.H{"message": "Pizza not found"})
}

func postPizzas(c *gin.Context){
	var newPizza models.Pizza
	if err := c.ShouldBindJSON(&newPizza); err != nil {
		c.JSON(400, gin.H{
			"erro": err.Error(),
		})
		return
	}
	pizzas = append(pizzas, newPizza)
}

func getPizzas(c *gin.Context) {

	c.JSON(200, gin.H{
		"pizzas": pizzas,
	})
	
}
func loadPizzas(){
	file, err := os.Open("dados/pizza.json")

	if err != nil {
		fmt.Println("Error file:", err)
		return
	}
	defer file.Close()
	decoder := json.NewDecoder(file)

	if err := decoder.Decode(&pizzas); err != nil {
		fmt.Println("Error decoding JSON: ", err)
	}
}


func savePizza(){
	file, err := os.Create("dados/pizza.json")

	if err != nil {
		fmt.Println("Error file:", err)
		return
	}
	defer file.Close()
}