package main

import (
	"fmt"
	"refazendoGo/models"
	"strconv"

	"github.com/gin-gonic/gin"
)
var pessoas []models.Pessoa
//primeira forma
var pessoa1 = models.Pessoa{
	Nome: "Thiago",
	Idade: 21,
	Ativo: true,
}
func main(){
	/*
	//segunda forma
	var p models.Pessoa
	p.Nome = "Thiago Gama"
	p.Idade = 21
	p.Ativo = true
	
	//terceira
	outraPessoa := models.Pessoa{"Thiago", 21, true}

	fmt.Println("Primeira forma: ", pessoa1)
	fmt.Println("2ª Forma:", p)
    fmt.Println("3ª Forma:", outraPessoa)*/

	router := gin.Default()
	router.GET("/msg", getMsg)
	router.POST("/dados", postJson)
	router.GET("/pessoas/:id", getID)
	router.Run()
}

func getMsg(c *gin.Context){
	c.JSON(200, "Boas vindas ao Go!")
}

func postJson(c *gin.Context){
	var newPessoa models.Pessoa

	if err := c.ShouldBindJSON(&newPessoa); err != nil {
		c.JSON(400, gin.H{
			"Erro ao ler JSON": err.Error(),
		})
		return
	}
	c.JSON(200, newPessoa)
	fmt.Println(newPessoa)
}
func getID(c *gin.Context){
	idStr := c.Param("id")
	_, err := strconv.Atoi(idStr)

	if err != nil {
		c.JSON(400, gin.H{
			"Erro ao buscar ID" : err.Error(),
		})
		return
	}
	
	c.JSON(200, gin.H{
		"mensagem" : "ID recebido : " + idStr,
	})
}