package models

type Pessoa struct {
	Nome  string `json:"nome"`
	Idade int    `json:"idade"`
	Ativo bool   `json:"ativo"`
}